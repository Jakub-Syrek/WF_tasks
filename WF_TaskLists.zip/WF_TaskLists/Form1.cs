﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_TaskLists
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            
        }
        public static TaskFactory taskFactory1 = TaskFactory.TaskFactorySingleton;
        private void Button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            System.Threading.CancellationTokenSource cancellationTokenSource = new System.Threading.CancellationTokenSource();            
            System.Threading.CancellationToken cancellationToken = cancellationTokenSource.Token;
            Task<decimal> task = TaskHelper.LongRunningOperationWithCancellationTokenAsync(100, cancellationToken);
            var taskToken = (Task: task, Token1: cancellationTokenSource); //<== New named Tuple introduced in 7.1
            //taskToken.Task = task;
            //taskToken.Token1 = cancellationTokenSource;                    
            taskFactory1.AddTask(taskToken);
            decimal res = taskFactory1.RunTask();
            textBox1.Text = res.ToString();
                        
        }
    }
}
