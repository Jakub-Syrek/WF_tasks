﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WF_TaskLists;

namespace WF_TaskLists
{
    public class TaskFactory
    {
        private static TaskFactory taskFactory;
        private static readonly object SyncObj = new object();        
        private IEnumerable<ValueTuple<Task<decimal>, CancellationTokenSource>> tasksTokensTuples;
        public IEnumerable<ValueTuple<Task<decimal>, CancellationTokenSource>> TasksTokens
        {
            get => tasksTokensTuples;
            set => tasksTokensTuples = value;
        }  
        public static TaskFactory TaskFactorySingleton
        {
            get
            {
                if (taskFactory == null)
                {
                    lock (SyncObj)
                    {
                        if (taskFactory == null)
                        {
                            taskFactory = new TaskFactory();
                        }
                    }
                }
                return taskFactory;
            }
        }        
        public void AddTask(ValueTuple<Task<decimal>, CancellationTokenSource> tuple)
        {
            if (tasksTokensTuples == null)
            {
                tasksTokensTuples = new ValueTuple< Task<decimal>, CancellationTokenSource>[] { tuple };
            }
            else if (tasksTokensTuples.Any())
            {
                tasksTokensTuples.ToList().ForEach(
                    tt =>
                    {
                        try
                        {
                            tt.Item2.Cancel();
                            tt.Item2.Dispose();
                            tt.Item1.Dispose();
                        }
                        catch
                        {
                        };
                    });
                tasksTokensTuples.Select(x=> x.Item2).Where(y=> y.IsCancellationRequested == true).All(z=>
                {
                    z = null;                    
                    return true;
                }).CompareTo(tasksTokensTuples.Select(x=>x.Item1).Where(y=>y.Result != 0).All(z=>
                {
                    z = null;
                    return true;
                }));                
                tasksTokensTuples.Concat(new ValueTuple<Task<decimal>, CancellationTokenSource>[] { tuple });
            }
        }
        public decimal RunTask()
        {
            tasksTokensTuples.First().Item1.Wait();
            return tasksTokensTuples.First().Item1.Result;           
            
        }        
    }
}
